


export class EmpModel{
    empName:string;
    empId:string;

}