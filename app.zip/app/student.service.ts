import { Injectable, OnInit } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions, RequestOptionsArgs } from '@angular/http';
import 'rxjs/Rx';
import { StudentMst } from './student.model';

@Injectable()
export class StudentService {
  url: string;
  returnedStudents: StudentMst[];
  constructor(private nativeHttp: Http) {

  }

  getUserDetails1(studentMst: StudentMst): StudentMst[] {
    
      alert("In Service");
      this.returnedStudents = [
      {
        "studentName": "Srikant", "roll": 44,
      }
        ,
      {
        "studentName": "Ashwin", "roll": 45,
      },
      {
        "studentName": "Venkat", "roll": 46,
      }
      ]
      return this.returnedStudents;

  }

  getUserDetails(student: StudentMst): Observable<StudentMst[]> {
   
    this.url="http://localhost:8081/corsRestForAng4/studentData";
     return this.nativeHttp.post(this.url,student,).map(res => res.json());
       

  }

}