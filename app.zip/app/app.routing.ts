import { ModuleWithProviders } from '@angular/core';
import { RouterModule } from '@angular/router';
import {StudentComponent} from './student.component'
import{EmpComponent} from './EmpReg.component';

export const router:ModuleWithProviders=RouterModule.forRoot([
                 {path:'',component:StudentComponent},


                 
			           {path:'emp',component:EmpComponent},

          
                {path:'emp/:ID',component:EmpComponent},
                  ])