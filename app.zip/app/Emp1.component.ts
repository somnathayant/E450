import { Component,OnInit} from '@angular/core';

import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';


import{Emp} from './emp.model';
import{router}from './app.routing';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'child',
  templateUrl: './Emp1.component.html',
  providers :[],
  styleUrls: ['./app.component.css']
})
export class EmpComponent implements OnInit { 
            empForm:FormGroup;
            userName:string;
            
        constructor(private fb:FormBuilder,private route:ActivatedRoute){
        }
        ngOnInit() {
               this.empForm = this.fb.group({
                'empName':new FormControl(''),
                'empId':new FormControl('')
            });
               
    }
    valueSubmission(emp:Emp){//same identical property for the formcontrolname
         alert("Form submission happened "+emp.empName);
    }
   
}