import { Component,OnInit} from '@angular/core';

import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';
import{Product} from './product.model'


@Component({
  selector: 'child',
  templateUrl: './Emp1.component.html',
  providers :[],
  styleUrls: ['./app.component.css']
})
export class ProductMst implements OnInit { 
            productRegForm:FormGroup;
            userName:string;
            
            
        constructor(private fb:FormBuilder){
        }
        ngOnInit() {

                this.productRegForm=this.fb.group({
                    "pPrice":new FormControl(''),
                    "pName":new FormControl('')
                });
               
               
    }
    valueSubmission(p:Product){//same identical property for the formcontrolname
         
    }
   
}