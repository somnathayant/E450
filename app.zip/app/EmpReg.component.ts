import { Component,OnInit,Input ,Output,EventEmitter} from '@angular/core';
import { Validators,FormControl,FormGroup,FormBuilder } from '@angular/forms';
import{StudentMst} from './student.model';
import{router}from './app.routing';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
  selector: 'child',
  templateUrl: './emp.html',
  styleUrls: ['./app.component.css']
})
export class EmpComponent implements OnInit { 
            empForm:FormGroup;
            value:string;
            _valueFromParent:string;
             userName:string;

             
             @Input()
          set valueFromParent(value : string ){
          alert("we are in child component "+value);
            this._valueFromParent = value; 

        }
        get valueFromParent(){
            return this._valueFromParent;
        }

        @Output() toParent :EventEmitter<string> = new EventEmitter<string>();
     
        constructor(private fb:FormBuilder,private route:ActivatedRoute){
            
        }
        ngOnInit() {
               this.empForm = this.fb.group({
                'empName':new FormControl(''),
                'empId':new FormControl('',Validators.pattern('^[^0-9]+$'))
            });

                this.userName=this.route.snapshot.params['ID'];
            
    }
    valueSubmission(student:StudentMst){//same identical property for the formcontrolname
         alert("Form submission happened "+student.studentName);
         this.toParent.emit("we are Angular");
         

    }
   
}