export class Product{
    pName:string;
    pPrice:number;

}